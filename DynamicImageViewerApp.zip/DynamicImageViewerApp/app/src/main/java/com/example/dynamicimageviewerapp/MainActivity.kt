package com.example.dynamicimageviewerapp

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the ImageView
        imageView = findViewById(R.id.imageView)

        // Initialize buttons and set click listeners
        val button1: Button = findViewById(R.id.button1)
        val button2: Button = findViewById(R.id.button2)
        val button3: Button = findViewById(R.id.button3)

        // Set click listeners for the buttons
        button1.setOnClickListener { switchImage(R.drawable.image1) }
        button2.setOnClickListener { switchImage(R.drawable.image2) }
        button3.setOnClickListener { switchImage(R.drawable.image3) }
    }

    private fun switchImage(imageResource: Int) {
        // Fade-out animation
        val fadeOut = ObjectAnimator.ofFloat(imageView, "alpha", 1f, 0f).apply {
            duration = 500 // Duration in milliseconds
        }

        // Fade-in animation
        val fadeIn = ObjectAnimator.ofFloat(imageView, "alpha", 0f, 1f).apply {
            duration = 500 // Duration in milliseconds
        }

        // Add a listener to the fade-out animation
        fadeOut.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                super.onAnimationEnd(animation)
                // Set the new image resource after fade-out
                imageView.setImageResource(imageResource)
                // Start the fade-in animation
                fadeIn.start()
            }
        })

        // Start the fade-out animation
        fadeOut.start()
    }
}

