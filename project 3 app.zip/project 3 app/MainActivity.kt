package com.example.dynamicimageviewer

import android.animation.ObjectAnimator
import android.animation.AnimatorListenerAdapter
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)

        val button1: Button = findViewById(R.id.button1)
        val button2: Button = findViewById(R.id.button2)
        val button3: Button = findViewById(R.id.button3)

        button1.setOnClickListener { switchImage(R.drawable.image1) }
        button2.setOnClickListener { switchImage(R.drawable.image2) }
        button3.setOnClickListener { switchImage(R.drawable.image3) }
    }

    private fun switchImage(imageResource: Int) {
        val fadeOut = ObjectAnimator.ofFloat(imageView, "alpha", 1f, 0f)
        val fadeIn = ObjectAnimator.ofFloat(imageView, "alpha", 0f, 1f)

        fadeOut.duration = 500
        fadeIn.duration = 500

        fadeOut.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                imageView.setImageResource(imageResource)
                fadeIn.start()
            }
        })

        fadeOut.start()
    }
}
